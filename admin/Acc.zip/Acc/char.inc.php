<?if (XPT!=1) exit;?>
<?
            $qCharID=($_SESSION["charID"])?$_SESSION["charID"]:$_SESSION["ID"];

//------------------------------------------------------------ CREATE CHARACTER
            if($_POST[action]!="create")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/create.gif" alt="create" width="191" height="9"></td>
              </tr>
              <tr>
                <td><input type="text" name="newchar" maxlength="12">
                <select name="class">
                <option>Fighter</option>
                <option>Mechanician</option>
                <option>Archer</option>
                <option>Pikeman</option>
                <option>Atalanta</option>
                <option>Knight</option>
                <option>Magician</option>
                <option>Priestess</option>
                </select>
                <input type="submit" value="create" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="create">

            </form>
<?

            }
            else
            {

                // Fill in 00 to left character
                $leftLen=10-strlen($qCharID);
                for($i=0;$i<$leftLen;$i++)
                {
                    $addOnLeft.=pack("h*",00);
                }
                $writeAccName=$qCharID.$addOnLeft;

                $charInfo=$dirUserInfo . ($func->numDir($qCharID)) . "/" . $qCharID . ".dat";

                if(!file_exists($charInfo))
                {
                    copy("create/info.dat",$dirUserInfo . ($func->numDir($qCharID)) . "/" . $qCharID. ".dat");

                    $fRead=false;
                    $fOpen = fopen($charInfo, "r");
                    while (!feof($fOpen)) {
                    @$fRead = "$fRead" . fread($fOpen, filesize($charInfo) );
                    }
                    fclose($fOpen);

                    // Change character class ----------------------------------------------------------------
                    $sourceStr = substr($fRead, 0, 16) . $writeAccName . substr($fRead, 26);
                    $fOpen = fopen($charInfo, "wb"); 
                    fwrite($fOpen, $sourceStr, strlen($sourceStr));
                    fclose($fOpen);

                    echo "INFORMATION FILE IS CREATED!";
                }
                else
                {
                    if( filesize($charInfo)==240)
                    {
                        $newName=trim($func->char_filter(trim($_POST["newchar"])),"\x00");

                        if(!$func->is_valid_string($newName))
                        {

                            $charDat = $dirUserData . ($func->numDir($newName)) . "/" . $newName . ".dat";

                            if(!file_exists($charDat))
                            {
                                copy("create/char.dat",$dirUserData . ($func->numDir($newName)) . "/" . $newName. ".dat");

                                $fRead=false;
                                $fOpen = fopen($charInfo, "r");
                                $fRead =fread($fOpen,filesize($charInfo));
                                @fclose($fOpen);

                                // list char information
                                $charNameArr=array(
                                    "48" => trim(substr($fRead,0x30,12),"\x00"),
                                    "80" => trim(substr($fRead,0x50,12),"\x00"),
                                    "112"=> trim(substr($fRead,0x70,12),"\x00"),
                                    "144"=> trim(substr($fRead,0x90,12),"\x00"),
                                    "176"=> trim(substr($fRead,0xb0,12),"\x00"),
                                );

                                $chkEmpArr=array();
                                $chkChar=array();
                                foreach($charNameArr as $key=>$value)
                                {
                                    if(empty($value)) $chkEmpArr[]=$key;
                                    else $chkChar[]=$key;
                                }

                                if(count($chkChar)<5)
                                {

                                    // point to each information line
                                    $startPoint=$chkEmpArr[0];
                                    $endPoint=$startPoint+12;

                                     // Write info-----------------------------------------------------------------------
                                    $fRead=false;
                                    $fOpen = fopen($charInfo, "r");
                                    while (!feof($fOpen)) {
                                    @$fRead = "$fRead" . fread($fOpen, filesize($charInfo) );
                                    }
                                    fclose($fOpen);

                                    // Fill in 00 to left character
                                    $addOnLeft=false;
                                    $leftLen=12-strlen($newName);
                                    for($i=0;$i<$leftLen;$i++)
                                    {
                                        $addOnLeft.=pack("h*",00);
                                    }
                                    $writeName=$newName.$addOnLeft;


                                    $sourceStr = substr($fRead, 0, $startPoint) . $writeName . substr($fRead, $endPoint);
                                    $fOpen = fopen($charInfo, "wb"); 
                                    fwrite($fOpen, $sourceStr, strlen($sourceStr));
                                    fclose($fOpen);

                                    // Write data-------------------------------------------------------------------------
                                    $fRead=false;
                                    $fOpen = fopen($charDat, "r");
                                    while (!feof($fOpen)) {
                                    @$fRead = "$fRead" . fread($fOpen, filesize($charDat) );
                                    }
                                    fclose($fOpen);

                                    $bin = $func->char2Num($_POST["class"]);
                                    $bina= pack("h*",$bin);

                                    // Change character class ----------------------------------------------------------------
                                    $sourceStr = substr($fRead, 0, 16) . $writeName . substr($fRead, 28, 20) . ($func->charResetHair($_POST['class'], 1)) . substr($fRead, 69, 43) . ($func->charResetHair($_POST['class'], 2)) . substr($fRead, 136, 60) . $bina . substr($fRead, 197, 7) . ($func->charResetState($_POST['class'])) . substr($fRead, 224, 284) . ($func->charResetSkill()) . substr($fRead, 524, 0) . ($func->charResetMastery()) . substr($fRead, 556, 148) . $writeAccName . substr($fRead, 714);
                                    $fOpen = fopen($charDat, "wb"); 
                                    fwrite($fOpen, $sourceStr, strlen($sourceStr));
                                    fclose($fOpen);


                                    echo "CHARACTER HAS FULLY CREATED!";



                                }
                                else
                                {
                                    echo "ACCOUNT IS FULL!";
                                }
                            }
                            else
                            {
                                echo "CHARACTER IS EXISTING!";
                            }

                        }
                        else
                        {
                            echo "PLEASE WRITE A NAME FOR YOUR NEW CHARACTER OR THE NAME IS NOT SUPPORTED!";
                        }


                    }
                    else
                    {
                        echo "INFORMATION FILE IS CORRUPTED!";
                    }
                }

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";

            }


//------------------------------------------------------------ RECOVER CHARACTER
            if($_POST[action]!="recover")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/recover.gif" alt="recover" width="205" height="9"></td>
              </tr>
              <tr>
                <td><input type="text" name="charrecover" maxlength="12"> <input type="submit" value="recover" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="recover">

            </form>
<?

            }
            else
            {
                $charRecover=trim($func->char_filter(trim($_POST["charrecover"])),"\x00");

                if(!$func->is_valid_string($charRecover))
                {

                    $charDatDelete = $dirUserDelete . "/" . $charRecover . ".dat";

                    if(file_exists($charDatDelete))
                    {

                        $fRead=false;
                        $fOpen = fopen($charDatDelete, "r");
                        $fRead =fread($fOpen,filesize($charDatDelete));
                        @fclose($fOpen);

                        // details
                        $charID = trim(substr($fRead,0x2c0,10),"\x00");
                        $charName = trim(substr($fRead,0x10,12),"\x00");

                        if( ($_SESSION["ID"]==$charID) || in_array($_SESSION["ID"],$adminList))
                        {

                            $charInfo=$dirUserInfo . ($func->numDir($charID)) . "/" . $charID . ".dat";

                            $fRead=false;
                            $fOpen = fopen($charInfo, "r");
                            $fRead =fread($fOpen,filesize($charInfo));
                            @fclose($fOpen);

                            // list char information
                            $charNameArr=array(
                                "48" => trim(substr($fRead,0x30,12),"\x00"),
                                "80" => trim(substr($fRead,0x50,12),"\x00"),
                                "112"=> trim(substr($fRead,0x70,12),"\x00"),
                                "144"=> trim(substr($fRead,0x90,12),"\x00"),
                                "176"=> trim(substr($fRead,0xb0,12),"\x00"),
                            );

                            $chkEmpArr=array();
                            $chkChar=array();
                            foreach($charNameArr as $key=>$value)
                            {
                                if(empty($value)) $chkEmpArr[]=$key;
                                else $chkChar[]=$key;
                            }

                            if(count($chkChar)<5)
                            {

                                // point to each information line
                                $startPoint=$chkEmpArr[0];
                                $endPoint=$startPoint+12;

                                 // Write info-----------------------------------------------------------------------
                                $fRead=false;
                                $fOpen = fopen($charInfo, "r");
                                while (!feof($fOpen)) {
                                @$fRead = "$fRead" . fread($fOpen, filesize($charInfo) );
                                }
                                fclose($fOpen);

                                // Fill in 00 to left character
                                $addOnLeft=false;
                                $leftLen=12-strlen($charName);
                                for($i=0;$i<$leftLen;$i++)
                                {
                                    $addOnLeft.=pack("h*",00);
                                }
                                $writeName=$charName.$addOnLeft;

                                $sourceStr = substr($fRead, 0, $startPoint) . $writeName . substr($fRead, $endPoint);
                                $fOpen = fopen($charInfo, "wb"); 
                                fwrite($fOpen, $sourceStr, strlen($sourceStr));
                                fclose($fOpen);

                                copy($dirUserDelete . "/" . $charName . ".dat", $dirUserData . ($func->numDir($charName)) . "/" .$charName . ".dat");
                                unlink($dirUserDelete . "/" . $charName . ".dat");

                                echo "CHARACTER ". $charName ." HAS BEEN RECOVERED!";

                            }
                            else
                            {
                                echo "ACCOUNT IS FULL";
                            }

                        }
                        else
                        {
                            echo "CHARACTER IS NOT YOUR OWN!";
                        }

                    }
                    else
                    {
                        echo "DELETE DATA IS NOT EXISTING!";
                    }

                }
                else
                {
                    echo "PLEASE WRITE A NAME FOR YOUR NEW CHARACTER OR THE NAME IS NOT SUPPORTED!";
                }

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";

            }



//------------------------------------------------------------ DELETE CHARACTER
        if($_SESSION["charDir"])
        {
            if($_POST[action]!="delete")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/delete.gif" alt="delete" width="191" height="9"></td>
              </tr>
              <tr>
                <td><input type="submit" value="delete" class="button" onClick="cf=confirm('warning: are you sure?');if(!cf){return false}"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="delete">

            </form>
<?

            }
            else
            {



                $charInfo=$dirUserInfo . ($func->numDir($qCharID)) . "/" . $qCharID . ".dat";

                $fRead=false;
                $fOpen = fopen($charInfo, "r");
                $fRead =fread($fOpen,filesize($charInfo));
                @fclose($fOpen);

                // list char information
                $charNameArr=array(
                    "48" => trim(substr($fRead,0x30,12),"\x00"),
                    "80" => trim(substr($fRead,0x50,12),"\x00"),
                    "112"=> trim(substr($fRead,0x70,12),"\x00"),
                    "144"=> trim(substr($fRead,0x90,12),"\x00"),
                    "176"=> trim(substr($fRead,0xb0,12),"\x00"),
                );

                $chkCharLine=array();
                foreach($charNameArr as $key=>$value)
                {
                    if($_SESSION["charName"]==$value) $chkCharLine[]=$key;
                }

                // Remove character from information file--------------------------------------

                // Fill in 00 to left character
                $addOnLeft=false;
                for($i=0;$i<12;$i++)
                {
                    $addOnLeft.=pack("h*",00);
                }

                $startPoint=$chkCharLine[0];
                $endPoint=$startPoint+12;

                $fRead=false;
                $fOpen = fopen($charInfo, "r");
                while (!feof($fOpen)) {
                @$fRead = "$fRead" . fread($fOpen, filesize($charInfo) );
                }
                fclose($fOpen);

                $sourceStr = substr($fRead, 0, $startPoint) . $addOnLeft . substr($fRead, $endPoint);
                $fOpen = fopen($charInfo, "wb"); 
                fwrite($fOpen, $sourceStr, strlen($sourceStr));
                fclose($fOpen);

                copy($dirUserData . ($func->numDir($_SESSION["charName"])) . "/" . $_SESSION["charName"] . ".dat" ,$dirUserDelete . "/" . $_SESSION["charName"] . ".dat");
                unlink($dirUserData . ($func->numDir($_SESSION["charName"])) . "/" . $_SESSION["charName"] . ".dat");

                echo "CHARACTER ". $_SESSION["charName"] ." IS DELETED!";

                $_SESSION["charDir"]='';
                $_SESSION["charNum"]='';
                $_SESSION["charID"]='';
                $_SESSION["charName"]='';
                $_SESSION["charLevel"]='';
                $_SESSION["charClass"]='';

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";

            }
        }



//------------------------------------------------------------ MOVE CHARACTER
        if($_SESSION["charDir"] && ( in_array($_SESSION["ID"],$modList) || in_array($_SESSION["ID"],$adminList) ))
        {
            if($_POST[action]!="move")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/move.gif" alt="move" width="170" height="9"></td>
              </tr>
              <tr>
                <td>ACC <input type="text" name="account" maxlength="10"> <input type="submit" value="move" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="move">

            </form>
<?

            }
            else
            {
                $accMove=trim($func->char_filter(trim($_POST["account"])),"\x00");

                if(!$func->is_valid_string($accMove))
                {

                    $charInfo=$dirUserInfo . ($func->numDir($accMove)) . "/" . $accMove . ".dat";

                    if(file_exists($charInfo) && ( filesize($charInfo)==240) )
                    {

                        $fRead=false;
                        $fOpen = fopen($charInfo, "r");
                        $fRead =fread($fOpen,filesize($charInfo));
                        @fclose($fOpen);

                        // list char information
                        $charNameArr=array(
                            "48" => trim(substr($fRead,0x30,12),"\x00"),
                            "80" => trim(substr($fRead,0x50,12),"\x00"),
                            "112"=> trim(substr($fRead,0x70,12),"\x00"),
                            "144"=> trim(substr($fRead,0x90,12),"\x00"),
                            "176"=> trim(substr($fRead,0xb0,12),"\x00"),
                        );

                        $chkEmpArr=array();
                        $chkChar=array();
                        foreach($charNameArr as $key=>$value)
                        {
                            if(empty($value)) $chkEmpArr[]=$key;
                            else $chkChar[]=$key;
                        }

                        if(count($chkChar)<5)
                        {

                            // point to each information line
                            $startPoint=$chkEmpArr[0];
                            $endPoint=$startPoint+12;

                            // update account information for new account information-------------------------
                            // Fill in 00 to left character
                            $addOnLeft=false;
                            $leftLen=12-strlen($_SESSION["charName"]);
                            for($i=0;$i<$leftLen;$i++)
                            {
                                $addOnLeft.=pack("h*",00);
                            }
                            $writeName=$_SESSION["charName"].$addOnLeft;

                            $fRead=false;
                            $fOpen = fopen($charInfo, "r");
                            while (!feof($fOpen)) {
                            @$fRead = "$fRead" . fread($fOpen, filesize($charInfo) );
                            }
                            fclose($fOpen);

                            $sourceStr = substr($fRead, 0, $startPoint) . $writeName . substr($fRead, $endPoint);
                            $fOpen = fopen($charInfo, "wb"); 
                            fwrite($fOpen, $sourceStr, strlen($sourceStr));
                            fclose($fOpen);


                            // empty character in account information-------------------------------------
                            $charInfo=$dirUserInfo . ($func->numDir($qCharID)) . "/" . $qCharID . ".dat";

                            $fRead=false;
                            $fOpen = fopen($charInfo, "r");
                            $fRead =fread($fOpen,filesize($charInfo));
                            @fclose($fOpen);

                            // list char information
                            $charNameArr=array(
                                "48" => trim(substr($fRead,0x30,12),"\x00"),
                                "80" => trim(substr($fRead,0x50,12),"\x00"),
                                "112"=> trim(substr($fRead,0x70,12),"\x00"),
                                "144"=> trim(substr($fRead,0x90,12),"\x00"),
                                "176"=> trim(substr($fRead,0xb0,12),"\x00"),
                            );

                            $chkCharLine=array();
                            foreach($charNameArr as $key=>$value)
                            {
                                if($_SESSION["charName"]==$value) $chkCharLine[]=$key;
                            }

                            // point to each information line
                            $startPoint=$chkCharLine[0];
                            $endPoint=$startPoint+12;

                            // Fill in 00 to left character
                            $addOnLeft=false;
                            for($i=0;$i<12;$i++)
                            {
                                $addOnLeft.=pack("h*",00);
                            }

                            $fRead=false;
                            $fOpen = fopen($charInfo, "r");
                            while (!feof($fOpen)) {
                            @$fRead = "$fRead" . fread($fOpen, filesize($charInfo) );
                            }
                            fclose($fOpen);


                            $sourceStr = substr($fRead, 0, $startPoint) . $addOnLeft . substr($fRead, $endPoint);
                            $fOpen = fopen($charInfo, "wb"); 
                            fwrite($fOpen, $sourceStr, strlen($sourceStr));
                            fclose($fOpen);

                            // update data information---------------------------------------------------------------------
                            // Fill in 00 to left character
                            $addOnLeft=false;
                            $leftLen=10-strlen($accMove);
                            for($i=0;$i<$leftLen;$i++)
                            {
                                $addOnLeft.=pack("h*",00);
                            }
                            $writeAccName=$accMove.$addOnLeft;

                            $fRead=false;
                            $fOpen = fopen($_SESSION["charDir"], "r");
                            while (!feof($fOpen)) {
                            @$fRead = "$fRead" . fread($fOpen, filesize($_SESSION["charDir"]) );
                            }
                            fclose($fOpen);

                            $sourceStr = substr($fRead, 0, 704) . $writeAccName . substr($fRead, 714);
                            $fOpen = fopen($_SESSION["charDir"], "wb"); 
                            fwrite($fOpen, $sourceStr, strlen($sourceStr));
                            fclose($fOpen);

                            echo "CHARACTER ". $_SESSION["charName"] ." HAS BEEN FULLY MOVED TO ". $accMove;

                            $_SESSION["charDir"]='';
                            $_SESSION["charNum"]='';
                            $_SESSION["charID"]='';
                            $_SESSION["charName"]='';
                            $_SESSION["charLevel"]='';
                            $_SESSION["charClass"]='';

                        }
                        else
                        {
                            echo "ACCOUNT IS FULL";
                        }


                    }
                    else
                    {
                        echo "CHARACTER INFORMATION IS NOT EXISTING OR CORRUPTED!";
                    }



                }
                else
                {
                    echo "RE-ENTER ACCOUNT NAME";
                }


                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";

            }
        }



//------------------------------------------------------------ RENAME CHARACTER
        if( ($_SESSION["charDir"]) && ( in_array($_SESSION["ID"],$modList) || in_array($_SESSION["ID"],$adminList) ))
        {
            if($_POST[action]!="rename")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/rename.gif" alt="rename" width="76" height="9"></td>
              </tr>
              <tr>
                <td><input type="text" value="<?=$_SESSION["charName"]?>" name="newchar" maxlength="12"> <input type="submit" value="rename" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="rename">

            </form>
<?

            }
            else
            {
                $newName=trim($func->char_filter(trim($_POST["newchar"])),"\x00");

                if(!$func->is_valid_string($newName))
                {

                    $charInfo=$dirUserInfo . ($func->numDir($_SESSION["charID"])) . "/" . $_SESSION["charID"] . ".dat";


                    if(file_exists($charInfo) && ( filesize($charInfo)==240) )
                    {

                        $fOpen = fopen($charInfo, "r");
                        $fRead =fread($fOpen,filesize($charInfo));
                        @fclose($fOpen);

                        // list char information
                        $charNameArr=array(
                            "48" => trim(substr($fRead,0x30,12),"\x00"),
                            "80" => trim(substr($fRead,0x50,12),"\x00"),
                            "112"=> trim(substr($fRead,0x70,12),"\x00"),
                            "144"=> trim(substr($fRead,0x90,12),"\x00"),
                            "176"=> trim(substr($fRead,0xb0,12),"\x00"),
                        );

                        $charDat = $dirUserData . ($func->numDir($newName)) . "/" . $newName . ".dat";

                        if(!file_exists($charDat))
                        {

                            unset($flagArr);
                            $flagArr=array();

                            $sessNameExp=explode("\x00",$_SESSION["charName"]);

                            foreach($charNameArr as $key=>$value)
                            {
                                $expValue=explode("\x00",$value);
                                if($sessNameExp[0]==$expValue[0])
                                    $flagArr[]=$key;
                            }

                            // point to each information line
                            $startPoint=$flagArr[0];
                            $endPoint=$startPoint+12;
        // Write info

                            $fRead=false;
                            $fOpen = fopen($charInfo, "r");
                            while (!feof($fOpen)) {
                            @$fRead = "$fRead" . fread($fOpen, filesize($charInfo) );
                            }
                            fclose($fOpen);

                            // Fill in 00 to left character
                            $leftLen=12-strlen($newName);
                            for($i=0;$i<$leftLen;$i++)
                            {
                                $addOnLeft.=pack("h*",00);
                            }
                            $writeName=$newName.$addOnLeft;

                            $sourceStr = substr($fRead, 0, $startPoint) . $writeName . substr($fRead, $endPoint);

                            $fOpen = fopen($charInfo, "wb"); 
                            fwrite($fOpen, $sourceStr, strlen($sourceStr));
                            fclose($fOpen);


        // Write data
                            $fRead=false;
                            $fOpen = fopen($_SESSION["charDir"], "r");
                            while (!feof($fOpen)) {
                            @$fRead = "$fRead" . fread($fOpen, filesize($_SESSION["charDir"]) );
                            }
                            fclose($fOpen);

                            $sourceStr = substr($fRead, 0, 16) . $writeName . substr($fRead, 28);
                            $fOpen = fopen($_SESSION["charDir"], "wb"); 
                            fwrite($fOpen, $sourceStr, strlen($sourceStr));
                            fclose($fOpen);

                            rename($dirUserData . $_SESSION["charNum"] . "/" . $_SESSION["charName"]. ".dat", $dirUserData . ($func->numDir($newName)) . "/" . $newName. ".dat");

                            echo $_SESSION["charName"] . " IS $newName NOW!";

                            $_SESSION["charDir"]=$dirUserData . ($func->numDir($newName)) . "/" . $newName. ".dat";
                            $_SESSION["charName"]=$newName;
                            $_SESSION["charNum"]=$func->numDir($newName);


                        }
                        else
                        {
                            echo "CHARACTER IS EXISTING!";
                        }

                    }
                    else
                    {
                        echo "CHARACTER INFORMATION IS NOT EXISTING OR CORRUPTED!";
                    }
                }
                else
                {
                    echo "REMOVE SPECIAL CHARACTER!";
                }

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";

            }

        }


//------------------------------------------------------------ CHANGE CLASS CHARACTER
        if($_SESSION["charDir"] && ( in_array($_SESSION["ID"],$modList) || in_array($_SESSION["ID"],$adminList) ))
        {
            if($_POST[action]!="class")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/class.gif" alt="class" width="57" height="9"></td>
              </tr>
              <tr>
                <td>
                <select name="class">
                <option <?=($_SESSION["charClass"]=="Fighter")?"selected":""?>>Fighter</option>
                <option <?=($_SESSION["charClass"]=="Mechanician")?"selected":""?>>Mechanician</option>
                <option <?=($_SESSION["charClass"]=="Archer")?"selected":""?>>Archer</option>
                <option <?=($_SESSION["charClass"]=="Pikeman")?"selected":""?>>Pikeman</option>
                <option <?=($_SESSION["charClass"]=="Atalanta")?"selected":""?>>Atalanta</option>
                <option <?=($_SESSION["charClass"]=="Knight")?"selected":""?>>Knight</option>
                <option <?=($_SESSION["charClass"]=="Magician")?"selected":""?>>Magician</option>
                <option <?=($_SESSION["charClass"]=="Priestess")?"selected":""?>>Priestess</option>
                </select>
                <input type="submit" value="change" class="button">
                </td>
              </tr>
            </table>
            <input type="hidden" name="action" value="class">

            </form>
<?

            }
            else
            {
                $fRead=false;
                $fOpen = fopen($_SESSION["charDir"], "r");
                while (!feof($fOpen)) {
                @$fRead = "$fRead" . fread($fOpen, filesize($_SESSION["charDir"]) );
                }
                fclose($fOpen);

                $bin = $func->char2Num($_POST["class"]);

                $bina= pack("h*",$bin);

                // Change character class ----------------------------------------------------------------
                $sourceStr = substr($fRead, 0, 48) . ($func->charResetHair($_POST['class'], 1)) . substr($fRead, 69, 43) . ($func->charResetHair($_POST['class'], 2)) . substr($fRead, 136, 60) . $bina . substr($fRead, 197, 7) . ($func->charResetState($_POST['class'])) . substr($fRead, 224, 284) . ($func->charResetSkill()) . substr($fRead, 524, 0) . ($func->charResetMastery()) . substr($fRead, 556);
                $fOpen = fopen($_SESSION["charDir"], "wb"); 
                fwrite($fOpen, $sourceStr, strlen($sourceStr));
                fclose($fOpen);

                $_SESSION["charClass"]=$_POST['class'];

                echo $_SESSION["charName"] , " IS $_POST[class] NOW!<br>";
                echo "ALL YOUR HAIRS, SKILLS AND STATE POINTS HAVE BEEN RESETED!";

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
            }

        }
?>
