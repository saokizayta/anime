﻿<?
ob_start('ob_gzhandler');

//session_start();

include_once "config.php";

if($_GET['sess']=="logout")
{
    session_unregister("usercode");
    $_SESSION["charDir"]='';
    $_SESSION["charNum"]='';
    $_SESSION["charID"]='';
    $_SESSION["charName"]='';
    $_SESSION["charLevel"]='';
    $_SESSION["charClass"]='';
    header("location: index.php");
}


if(!session_is_registered("usercode"))
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?=$version?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!-- 
function disabledBttn(formname)
{
    if (document.all || document.getElementById) {
        for (i=0;i<formname.length;i++) {
            var bttn=formname.elements[i];
            if(bttn.type.toLowerCase()=="submit" || bttn.type.toLowerCase()=="reset" || bttn.type.toLowerCase()=="button")
                bttn.disabled=true;
        }
    }
}
//-->
</script>
</head>

<body leftmargin="0" topmargin="10" marginwidth="0" marginheight="0">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
      <table width="350" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><img src="imgs/top/logo.png" alt="PTvui" width="200" height="200"></td>
        </tr>
        <tr>
          <td style="font-size:5px">&nbsp;</td>
        </tr>
        <tr>
          <td align="center" bgcolor="white" style="border-bottom: solid 1px #cecece; border-top: solid 1px #cecece; border-left: solid 1px #cecece; border-right: solid 1px #cecece" class="padding_all">
<?
    if($_POST['action']!="login")
    {
?>

            <!--<form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td colspan="2"><img src="imgs/box/adminlogin.gif" alt="adminlogin" width="131" height="9"></td>
              </tr>
              <tr>
                <td width="10%">ID</td><td><input type="text" name="username" size="20" maxlength="8"></td>
              </tr>
              <tr>
                <td>PW</td><td><input type="password" name="password" size="20" maxlength="8"></td>
              </tr>
              <tr>
                <td colspan="2" align="right"><input type="submit" value="login" class="button"> <input type="reset" value="clear" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="login">
            </form>-->
                <h4><b> free for fun !<br><br> Open Beta: 11 Jan 2021</b> </h4>
        <!-- <h4><b> free for fun !<br><br> Thank for: Thien Son, Minh Ngoc, Hiền Đặng, Lê Anh</b> </h4>-->

<?
    }
    else
    {
        $required=array(
            "ID"=>$_POST[username],
            "PW"=>$_POST[password],
        );



        for($i=0;$i<count($required);$i++)
        {
            list($key,$value)=each($required);

            if(!$value)
                echo "<b>$key</b> is required<br>";
            else
                $chkArr[]=true;
        }

        if(count($chkArr)==count($required))
        {

            $connection = odbc_connect( $connection_string, $user, $pass );


            $usernameP=$_POST[username];
            $query = "SELECT * FROM [accountdb].[dbo].[".( strtoupper($usernameP[0]) ) ."GameUser] WHERE [userid]='$_POST[username]' AND [Passwd]='$_POST[password]'";
            $q = odbc_exec($connection, $query);

            $qt = odbc_do($connection, $query);
            $i = 0;
            while(odbc_fetch_row($qt)) $i++;

            if($i>0)
            {

                session_register("usercode");
                $farr = odbc_fetch_array($q);

                $_SESSION["ID"]=$farr[userid];

                echo "LOGIN SUCCEED!";
            }
            else
                echo "CONNECTION FAILED!";

        }
        echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
    }

?>
          </td>
        </tr>
      </table>

      <br>

      <table width="350" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td align="center" bgcolor="white" style="border-bottom: solid 1px #cecece; border-top: solid 1px #cecece; border-left: solid 1px #cecece; border-right: solid 1px #cecece" class="padding_all">
<?
    if($_POST[action]!="signup")
    {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td colspan="2"><img src="imgs/box/signup.gif" alt="signup" width="162" height="9"></td>
              </tr>
              <tr>
                <td width="10%">ID</td><td><input type="text" name="username" size="20" maxlength="8"></td>
              </tr>
              <tr>
                <td>PW</td><td><input type="password" name="password" size="20" maxlength="8"></td>
              </tr>
              <tr>
                <td colspan="2" align="right"><input type="submit" value="regis" class="button"> <input type="reset" value="clear" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="signup">
            </form>



<?
    }
    else
    {
        $required=array(
            "ID"=>$_POST[username],
            "PW"=>$_POST[password],
        );



        for($i=0;$i<count($required);$i++)
        {
            list($key,$value)=each($required);

            if(!$value)
                echo "<b>$key</b> is required<br>";
            else
                $chkArr[]=true;
        }

        if(count($chkArr)==count($required))
        {

            $connection = odbc_connect( $connection_string, $user, $pass );

            if(!$func->is_valid_string($_POST[username]) && !$func->is_valid_string($_POST[password]))
            {

                $usernameP=$_POST[username];
                $query = "SELECT * FROM [AccountDB].[dbo].[AllGameUser] WHERE [userid]='$usernameP'";
                $q = odbc_exec($connection, $query);

                $qt = odbc_do($connection, $query);
                $i = 0;
                while(odbc_fetch_row($qt)) $i++;

                if($i>0)
                    echo"USERNAME <b>$_POST[username]</b> ĐÃ TỒN TẠI TRONG HỆ THỐNG!";
                else           
                {
                  $query = "INSERT INTO [AccountDB].[dbo].[AllGameUser] ([userid],[Passwd],[GameCode],[GPCode],[RegistDay],[DisuseDay],[UsePeriod],[inuse],[Grade],[EventChk],[SelectChk],[BlockChk],[SpecialChk],[ServerName],[Credit],[ECoin]
                  ,[StartDay],[LastDay],[EditDay],[RNo],[DelChk],[SNo],[Channel],[BNum],[MXServer],[MXChar],[MXType],[MXLevel],[MXExp],[BlockMOTIVO],[BlockDATA]
                    VALUES ('$_POST[username]','$_POST[password]','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',)";
                  //$query = "INSERT INTO [userdb].[dbo].[UserInfo] ([AccountName],[Password],[RegisDay],[Flag],[Active],[ActiveCode],[Coins],[Email],[GameMasterType],[GameMasterLevel],[GameMasterMacAddress],[CoinsTraded],[BanStatus],[UnbanDate]) VALUES('$_POST[username]','$_POST[password]','10/10/2020','114','1','0','0','test@gmail.com','0','0','0','0','0',NULL)";

                    $q = odbc_exec($connection, $query);
                    if($q)
                         echo"USERNAME <b>$_POST[username]</b> ĐĂNG KÍ THÀNH CÔNG!";

                }
            }
            else
                echo"PLEASE RE-ENTER USENAME AND PASSWORD, REMOVE ALL SPECIAL CHARACTER!";

        }
        echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">Ấn vào đây để trở lại</a>";
    }

?>
          </td>
        </tr>
        <tr>
          <td bgcolor="#7f7f7f"><img src="imgs/bot/copy.gif" alt="copy" width="148" height="15"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>



</body>
</html>
<?
    exit;
}

include_once "index2.php";

ob_end_flush();
?>
