<?
define("XPT","1");

/*----------------------------------------------------------------------
(c)2007 THAIKHOA - XTREMEVNPT TEAM (JUST BE SOLO ^_^)
 USED FOR NON-COMMERCIAL AND FAN OF PRISTONTALE SERVER
 CONTACT ME IF YOU HAVE SOME PROBLEMS
 EMAIL: thaikhoa@gmail.com
 XTREMEVN PT
 GAME IP: 210.245.33.245
 WEB: http://210.245.33.245:8080
 THANK YOU FOR USING MY XPT SCRIPTS!
 THANK L3zToXz FOR GOOD IDEAS AND THE XP FILE!

DOWNLOAD AND INSTALL PHP BINARY FROM http://www.php.net/downloads.php
CLICK NEXT, NEXT, NEXT, SELECT ISS CGI AND NEXT THEN CLICK INSTALL
USE ODBC
----------------------------------------------------------------------*/

// version;
$version="PTvui: Account manager/ version 1.21";

include_once "class.func.php";
$func=new func;

// PRISTON TALE SERVER ROOT
$rootDir = "D:/GAMES/PTServer/";

// PRISTON TALE DATASERVER
// EVERYONE PERMISSION
$dirUserData = $rootDir."DataServer/userdata/";
$dirUserInfo = $rootDir."DataServer/userinfo/";
$dirUserDelete = $rootDir."DataServer/deleted/";

// ADMIN ACCOUNT
// FULLY CONTROL CHARACTER
// EDIT LEVEL / GOLD / MOVE CHAR / RENAME CHAR / CHANGE CLASS / RANK UP TIER / SHOW USER PASSWORD
$adminList=array();
$adminList[]="xpt";
$adminList[]="sonnb";
$adminList[]="caohuong18";

// MOD ACCOUNT
// MOVE CHAR / RENAME CHAR / CHANGE CLASS / CREATE / RECOVER / DELTETE 
$modList=array();
$modList[]="link";

// NORMAL USER
// CREATE / RECOVER / DELTETE / EDIT SKILL,STATE POINTS / CREATE, CHANGE PW ACCOUNT


// CHANGE XXXX TO YOUR COMPUTER NAME
$connection_string = 'DRIVER={SQL Server};SERVER=DESKTOP-ANH9Q98\SQLEXPRESS;DATABASE=userdb';

// CHANGE SQLEXPRESS USER AND PASSWORD
$user = 'sa';
$pass = 'm@2409';
?>       
