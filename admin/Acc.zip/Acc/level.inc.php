<?if (XPT!=1) exit;?>
<?
        if( in_array($_SESSION["ID"],$adminList) )
        {
            if($_POST[action]!="level")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/level.gif" alt="level" width="58" height="9"></td>
              </tr>
              <tr>
                <td>
                <select name="level">
<?
                for($i=1; $i<120; $i++)
                {
                    echo "<option ". ( ($i == $_SESSION["charLevel"] )? "selected" : "" ) .">". $i ."</option>";
                }
?>
                </select>
                <input type="submit" value="change" class="button">
                </td>
              </tr>
            </table>
            <input type="hidden" name="action" value="level">

            </form>

<?
            }
            else
            {
                $fRead=false;
                $fOpen = fopen($_SESSION["charDir"], "r");
                while (!feof($fOpen)) {
                @$fRead = "$fRead" . fread($fOpen, filesize($_SESSION["charDir"]) );
                }
                fclose($fOpen);

                $xphex = fopen('xphex.txt', "r");
                while (!feof($xphex)) 
                {
                @$xp =$xp . fread($xphex, filesize('xphex.txt') );
                }
                fclose($xphex);
                $xp = substr($xp, ($_POST[level] -1 ) * 14 , 12);

                $level1= pack('i', $_POST[level]);

                $level2 =substr ($xp, 0, 4);
                $level2=hexdec("$level2");
                $level2= pack('i', $level2);

                $level3 =substr ($xp, 4, 8);
                $level3=hexdec("$level3");
                $level3= pack('i', $level3);

                $sourceStr = substr($fRead, 0 , 200) . $level1 . substr($fRead, 204, 0). ($func->charResetState($_SESSION["charClass"])) . substr($fRead, 224, 108) . $level3 . substr($fRead, 336 ,68) . $level2 . substr($fRead,408, 100) . ($func->charResetSkill()) . substr($fRead, 524);

                $fOpen = fopen($_SESSION["charDir"], "wb"); 
                fwrite($fOpen, $sourceStr, strlen($sourceStr));
                fclose($fOpen);

                echo "CHAR ". $_SESSION["charName"] . " IS LEVEL $_POST[level]<br>"; 
                echo "ALL YOUR SKILLS AND STATE POINTS HAVE BEEN RESETED!";

                $_SESSION["charLevel"]=ord($level1);

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
            }
        }
?>
