<?if (XPT!=1) exit;?>
<?
    if( in_array($_SESSION["ID"],$adminList) )
    {

        $fOpen = fopen($_SESSION["charDir"], "r");
        $fRead =fread($fOpen,4096);

        @fclose($fOpen);

        // details
        $gold1 = bin2hex(substr($fRead,0x154,1));
        $gold2 = bin2hex(substr($fRead,0x155,1));
        $gold3 = bin2hex(substr($fRead,0x156,1));
        $gold4 = bin2hex(substr($fRead,0x157,1));

        $gold = hexdec("$gold4"."$gold3"."$gold2"."$gold1");

        if($_POST[action]!="gold")
        {
?>

        <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
        <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
          <tr>
            <td><img src="imgs/box/gold.gif" alt="gold" width="155" height="9"></td>
          </tr>
          <tr>
            <td><input type="text" name="gold" value="<?=$gold?>" maxlength="9"> <input type="submit" value="submit" class="button"></td>
          </tr>
        </table>
        <input type="hidden" name="action" value="gold">

        </form>

<?
        }
        else
        {
            $_POST['gold']=$func->getInt($_POST['gold']);

            if( $_POST['gold']<=100000000)
            {
                $fRead=false;
                $fOpen = fopen($_SESSION["charDir"], "r");
                while (!feof($fOpen)) {
                @$fRead = "$fRead" . fread($fOpen, filesize($_SESSION["charDir"]) );
                }
                fclose($fOpen);

                $gold=pack("i",$_POST['gold']);

                $sourceStr = substr($fRead, 0, 340) . $gold . substr($fRead, 344);
                $fOpen = fopen($_SESSION["charDir"], "wb"); 
                fwrite($fOpen, $sourceStr, strlen($sourceStr));
                fclose($fOpen);


                echo "YOU HAVE JUST BEEN ADDED ".$_POST['gold']."!";
            }
            else
            {
                echo "MAX GOLD 100000000!";
            }

            echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
        }
    }
?>
