<?if (XPT!=1) exit;?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title><?=$version?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/style.css" rel="stylesheet" type="text/css">
<script language="JavaScript" type="text/JavaScript">
<!-- 
function disabledBttn(formname)
{
    if (document.all || document.getElementById) {
        for (i=0;i<formname.length;i++) {
            var bttn=formname.elements[i];
            if(bttn.type.toLowerCase()=="submit" || bttn.type.toLowerCase()=="reset" || bttn.type.toLowerCase()=="button")
                bttn.disabled=true;
        }
    }
}
//-->
</script>

</head>

<body leftmargin="0" topmargin="10" marginwidth="0" marginheight="0">
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>
      <table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td><img src="imgs/top/xpt.gif" alt="XPT" width="93" height="30"></td>
        </tr>
        <tr>
          <td style="font-size:5px">&nbsp;</td>
        </tr>
        <tr>
          <td><a href="?sess=char"><img src="imgs/menu/char.gif" alt="class" width="61" height="24" border="0"></a><a href="?sess=level"><img src="imgs/menu/level.gif" alt="level" width="59" height="24" border="0"></a><a href="?sess=skill"><img src="imgs/menu/skill.gif" alt="skill" width="57" height="24" border="0"></a><a href="?sess=state"><img src="imgs/menu/state.gif" alt="state" width="91" height="24" border="0"></a><a href="?sess=gold"><img src="imgs/menu/gold.gif" alt="gold" width="57" height="24" border="0"></a><a href="?sess=changepw"><img src="imgs/menu/changepw.gif" alt="changepw" width="94" height="24" border="0"><a><a  href="?sess=logout"><img src="imgs/menu/logout.gif" alt="logout" width="78" height="24" border="0"></a></td>
        </tr>
        <tr>
          <td style="font-size:5px">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="white" style="border-bottom: solid 1px #cecece; border-top: solid 1px #cecece; border-left: solid 1px #cecece; border-right: solid 1px #cecece" class="padding_all">

<?
$CHAR=($_GET["char"])?$_GET["char"]:$_POST["char"];

if( !$CHAR )
{
?>
            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td>CHAR <input type="text" name="char" size="20" maxlength="15"> <input type="submit" value="submit" class="button"></td>
              </tr>
            </table>
            </form>

<?
}
else
{

    $charDat = $dirUserData . ( $func->numDir($CHAR) ) . "/" . $CHAR . ".dat";

    if(file_exists($charDat) && ( (filesize($charDat)==16384) || (filesize($charDat)==111376) || (filesize($charDat)==220976) ) )
    {

        $fOpen = fopen($charDat, "r");
        $fRead =fread($fOpen,filesize($charDat));
        @fclose($fOpen);

        // details
        $charLevel = substr($fRead,0xc8,1);
        $charClass = substr($fRead,0xc4,1);
        $charName = trim(substr($fRead,0x10,12),"\x00");
        $charID = trim(substr($fRead,0x2c0,10),"\x00");

        if( ($charID==$_SESSION["ID"]) || in_array($_SESSION["ID"],$adminList))
        {

            if($CHAR==$charName)
            {

                switch (ord($charClass))
                {
                    case 1: $class = 'Fighter'; break;
                    case 2: $class = 'Mechanician'; break;
                    case 3: $class = 'Archer'; break;
                    case 4: $class = 'Pikeman'; break;
                    case 5: $class = 'Atalanta'; break;
                    case 6: $class = 'Knight'; break;
                    case 7: $class = 'Magician'; break;
                    case 8: $class = 'Priestess'; break;
                }

                $_SESSION["charDir"]=$charDat;
                $_SESSION["charNum"]=$func->numDir($CHAR);
                $_SESSION["charID"]=$charID;
                $_SESSION["charName"]=$charName;
                $_SESSION["charLevel"]=ord($charLevel);
                $_SESSION["charClass"]=$class;
                header("location: index.php");
            }
            else
            {
                $expName=explode("\x00",$charName);

                $fRead=false;
                $fOpen = fopen($charDat, "r");
                while (!feof($fOpen)) {
                @$fRead = "$fRead" . fread($fOpen, filesize($charDat) );
                }
                fclose($fOpen);

                // Fill in 00 to left character
                $addOnLeft=false;
                $leftLen=32-strlen($expName[0]);
                for($i=0;$i<$leftLen;$i++)
                {
                    $addOnLeft.=pack("h*",00);
                }
                $writeName=$expName[0].$addOnLeft;

                $sourceStr = substr($fRead, 0, 16) . $writeName . substr($fRead, 48);
                $fOpen = fopen($charDat, "wb"); 
                fwrite($fOpen, $sourceStr, strlen($sourceStr));
                fclose($fOpen);


                echo "CLEAR UP YOUR FILE, RE-ENTER!";
            }


        }
        else
        {
            echo "CHARACTER IS NOT YOUR OWN!";
        }
    }
    else
    {
        echo "CHARACTER IS NOT EXISTING OR DATA FILE CORRUPTED!";
    }

    echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";

}

?>
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td colspan="2"><img src="imgs/box/charinfo.gif" alt="adminlogin" width="164" height="9"></td>
              </tr>
<?
if($_SESSION["charDir"])
{
?>

              <tr>
                <td width="15%">DIR</td><td style="border-bottom: solid 1px #cecece;"><?=$_SESSION["charDir"]?></td>
              </tr>
              <tr>
                <td>ID</td><td style="border-bottom: solid 1px #cecece;"><?=$_SESSION["charID"]?></td>
              </tr>
              <tr>
                <td>NAME</td><td style="border-bottom: solid 1px #cecece;"><?=$_SESSION["charName"]?></td>
              </tr>
              <tr>
                <td>LEVEL</td><td style="border-bottom: solid 1px #cecece;"><?=$_SESSION["charLevel"]?></td>
              </tr>
              <tr>
                <td>CLASS</td><td style="border-bottom: solid 1px #cecece;"><?=$_SESSION["charClass"]?></td>
              </tr>
<?
}
?>
              <tr>
                <td width="15%">ACC CHAR</td>
                <td style="border-bottom: solid 1px #cecece;">
<?
            $qCharID=($_SESSION["charID"])?$_SESSION["charID"]:$_SESSION["ID"];
            $charInfo=$dirUserInfo . ($func->numDir($qCharID)) . "/" . $qCharID . ".dat";

            if(file_exists($charInfo) && ( filesize($charInfo)==240) )
            {
                $fRead=false;
                $fOpen = fopen($charInfo, "r");
                $fRead =fread($fOpen,filesize($charInfo));
                @fclose($fOpen);

                // list char information
                $charNameArr=array(
                    "48" => trim(substr($fRead,0x30,12),"\x00"),
                    "80" => trim(substr($fRead,0x50,12),"\x00"),
                    "112"=> trim(substr($fRead,0x70,12),"\x00"),
                    "144"=> trim(substr($fRead,0x90,12),"\x00"),
                    "176"=> trim(substr($fRead,0xb0,12),"\x00"),
                );

                if(count($charNameArr)>0)
                {
                    foreach($charNameArr as $key=>$value)
                    {
                        $expValue=explode("\x00",$value);
                        echo "<a href=\"?char=".$expValue[0]."\">".$expValue[0]."</a>&nbsp;&nbsp;";
                    }
                }
                else
                {
                    echo "EMPTY";
                }

            }
            else
            {
                echo "EMPTY";
            }

?>                </td>
              </tr>
            </table>

<?



$sess=(!$_GET[sess])?"char":$_GET[sess];


switch($sess)
{

    case "level":
        ($_SESSION["charDir"])?include_once "level.inc.php":"";
    break;

    case "char":
        include_once "char.inc.php";
    break;

    case "skill":
        ($_SESSION["charDir"])?include_once "skill.inc.php":"";
    break;

    case "state":
        ($_SESSION["charDir"])?include_once "state.inc.php":"";
    break;

    case "gold":
        ($_SESSION["charDir"])?include_once "gold.inc.php":"";
    break;

    case "changepw":
        include_once "changepw.inc.php";
    break;
}


?>          </td>
        </tr>
        <tr>
          <td bgcolor="#7f7f7f"><img src="imgs/bot/copy.gif" alt="copy" width="148" height="15"></td>
        </tr>
      </table>
    </td>
  </tr>
</table>

</body>
</html>
