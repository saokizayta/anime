<?if (XPT!=1) exit;?>
<?

        if($_SESSION["charLevel"]<70)
        {
            echo"YOUR CHARACTER MUST BE LARGER THAN LEVEL 70";
        }
        else
        {
            $fOpen = fopen($_SESSION["charDir"], "r");
            $fRead =fread($fOpen,4096);

            @fclose($fOpen);

            // details
            $tier0_1 = ord(substr($fRead,0x1fd,2));
            $tier0_2 = ord(substr($fRead,0x1fe,2));
            $tier0_3 = ord(substr($fRead,0x1ff,2));
            $tier0_4 = ord(substr($fRead,0x200,2));

            $tier1_1 = ord(substr($fRead,0x201,2));
            $tier1_2 = ord(substr($fRead,0x202,2));
            $tier1_3 = ord(substr($fRead,0x203,2));
            $tier1_4 = ord(substr($fRead,0x204,2));

            $tier2_1 = ord(substr($fRead,0x205,2));
            $tier2_2 = ord(substr($fRead,0x206,2));
            $tier2_3 = ord(substr($fRead,0x207,2));
            $tier2_4 = ord(substr($fRead,0x208,2));

            $tier3_1 = ord(substr($fRead,0x209,2));
            $tier3_2 = ord(substr($fRead,0x20A,2));
            $tier3_3 = ord(substr($fRead,0x20B,2));
            $tier3_4 = ord(substr($fRead,0x1fc,2));

            $defaultSP=$func->checkSkillPoints($_SESSION["charLevel"],'SP');
            $defaultEP=$func->checkSkillPoints($_SESSION["charLevel"],'EP');

            $totalSP=$tier0_1+$tier0_2+$tier0_3+$tier0_4+
            $tier1_1+$tier1_2+$tier1_3+$tier1_4+
            $tier2_1+$tier2_2+$tier2_3+$tier2_4;

            $totalEP=$tier3_1+$tier3_2+$tier3_3+$tier3_4;

            if($_POST[action]!="skill")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/skill.gif" alt="skill" width="55" height="9"></td>
              </tr>
              <tr>
                <td><table width="100%" border="0" cellspacing="0" cellpadding="0" class="padding_all">
                  <tr>
                    <td colspan="4" bgcolor="#92C5DC" style="font-weight: bolder"><img src="imgs/box/tier1.gif" alt="tier1" width="37" height="10" /></td>
                  </tr>
                  <tr>
                    <td bgcolor="#e5e5e5"><select name="tier0_1">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier0_1==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier0_2">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier0_2==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier0_3">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier0_3==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier0_4">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier0_4==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                  </tr>
                  <tr>
                    <td colspan="4">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="4" bgcolor="#92C5DC" style="font-weight: bolder"><img src="imgs/box/tier2.gif" alt="tier2" width="37" height="10" /></td>
                  </tr>
                  <tr>
                    <td bgcolor="#e5e5e5"><select name="tier1_1">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier1_1==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier1_2">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier1_2==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier1_3">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier1_3==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier1_4">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier1_4==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                  </tr>
                  <tr>
                    <td colspan="4">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="4" bgcolor="#92C5DC" style="font-weight: bolder"><img src="imgs/box/tier3.gif" alt="tier3" width="37" height="10" /></td>
                  </tr>
                  <tr>
                    <td bgcolor="#e5e5e5"><select name="tier2_1">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier2_1==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier2_2">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier2_2==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier2_3">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier2_3==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier2_4">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier2_4==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                  </tr>
                  <tr>
                    <td colspan="4">&nbsp;</td>
                  </tr>
                  <tr>
                    <td colspan="4" bgcolor="#92C5DC" style="font-weight: bolder"><img src="imgs/box/tier4.gif" alt="tier4" width="37" height="10" /></td>
                  </tr>
                  <tr>
                    <td bgcolor="#e5e5e5"><select name="tier3_1">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier3_1==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier3_2">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier3_2==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier3_3">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier3_3==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                    <td bgcolor="#e5e5e5"><select name="tier3_4">
                      <?
                for($i=1; $i<=10; $i++)
                {
                    echo "<option ". ( ($tier3_4==$i)?"selected":"" ) .">". $i ."</option>";
                }
?>
                    </select></td>
                  </tr>


                </table></td>
              </tr>
              <tr>
                <td align="right">SP: <?=$defaultSP-$totalSP?> / EP: <?=$defaultEP-$totalEP?></td>
              </tr>
              
              <tr>
                <td><input type="submit" value="change" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="skill">

            </form>

<?
            }
            else
            {
                $checkSubmitSP=$_POST['tier0_1']+$_POST['tier0_2']+$_POST['tier0_3']+$_POST['tier0_4']+
            $_POST['tier1_1']+$_POST['tier1_2']+$_POST['tier1_3']+$_POST['tier1_4']+
            $_POST['tier2_1']+$_POST['tier2_2']+$_POST['tier2_3']+$_POST['tier2_4'];

                $checkSubmitEP=$_POST['tier3_1']+$_POST['tier3_2']+$_POST['tier3_3']+$_POST['tier3_4'];

                if( ($checkSubmitSP>$defaultSP) || ($checkSubmitEP>$defaultEP))
                {
                    echo "YOUR SUBMISSION SP (". $checkSubmitSP .") IS LARGER THAN DEFAULT SP (". $defaultSP .") ! OR<br>";
                    echo "YOUR SUBMISSION EP (". $checkSubmitEP .") IS LARGER THAN DEFAULT EP (". $defaultEP .") !";
                }
                else
                {
                    $tier0_1=trim(pack("i",$_POST['tier0_1']),"\x00");
                    $tier0_2=trim(pack("i",$_POST['tier0_2']),"\x00");
                    $tier0_3=trim(pack("i",$_POST['tier0_3']),"\x00");
                    $tier0_4=trim(pack("i",$_POST['tier0_4']),"\x00");

                    $tier1_1=trim(pack("i",$_POST['tier1_1']),"\x00");
                    $tier1_2=trim(pack("i",$_POST['tier1_2']),"\x00");
                    $tier1_3=trim(pack("i",$_POST['tier1_3']),"\x00");
                    $tier1_4=trim(pack("i",$_POST['tier1_4']),"\x00");

                    $tier2_1=trim(pack("i",$_POST['tier2_1']),"\x00");
                    $tier2_2=trim(pack("i",$_POST['tier2_2']),"\x00");
                    $tier2_3=trim(pack("i",$_POST['tier2_3']),"\x00");
                    $tier2_4=trim(pack("i",$_POST['tier2_4']),"\x00");

                    $tier3_1=trim(pack("i",$_POST['tier3_1']),"\x00");
                    $tier3_2=trim(pack("i",$_POST['tier3_2']),"\x00");
                    $tier3_3=trim(pack("i",$_POST['tier3_3']),"\x00");
                    $tier3_4=trim(pack("i",$_POST['tier3_4']),"\x00");

                    $skillStr=$tier3_4.$tier0_1.$tier0_2.$tier0_3.$tier0_4.
                        $tier1_1.$tier1_2.$tier1_3.$tier1_4.
                        $tier2_1.$tier2_2.$tier2_3.$tier2_4.
                        $tier3_1.$tier3_2.$tier3_3;

                    $fRead=false;
                    $fOpen = fopen($_SESSION["charDir"], "r");
                    while (!feof($fOpen)) {
                    @$fRead = "$fRead" . fread($fOpen, filesize($_SESSION["charDir"]) );
                    }
                    fclose($fOpen);

                    $sourceStr = substr($fRead, 0, 508) . $skillStr . substr($fRead, 524, 0) . ($func->charFullMastery()) . substr($fRead, 556);
                    $fOpen = fopen($_SESSION["charDir"], "wb"); 
                    fwrite($fOpen, $sourceStr, strlen($sourceStr));
                    fclose($fOpen);

                    echo "ALL SKILLS ARE SET AND ADD 100% SKILL MASTERY!";

                }

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
            }

        }

//------------------------------------------------------------ RANK UP QUEST
    if( in_array($_SESSION["ID"],$adminList) )
    {
        $fOpen = fopen($_SESSION["charDir"], "r");
        $fRead =fread($fOpen,4096);
        @fclose($fOpen);

        // details
        $job = ord(substr($fRead,0x184,2));

        if($_POST[action]!="rank")
        {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td><img src="imgs/box/rank.gif" alt="rank" width="80" height="9"></td>
              </tr>
              <tr>
                <td>
                <select name="job">
                <option <?=($job==1)?"selected":""?>>0</option>
                <option <?=($job==1)?"selected":""?>>1</option>
                <option <?=($job==2)?"selected":""?>>2</option>
                <option <?=($job==3)?"selected":""?>>3</option>
                </select>
                <input type="submit" value="change" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="rank">

            </form>
<?
        }
        else
        {


            $fRead=false;
            $fOpen = fopen($_SESSION["charDir"], "r");
            while (!feof($fOpen)) {
            @$fRead = "$fRead" . fread($fOpen, filesize($_SESSION["charDir"]) );
            }
            fclose($fOpen);

            $changejob=pack("i",$_POST['job']);

            $sourceStr = substr($fRead, 0, 388) . $changejob . substr($fRead, 392);
            $fOpen = fopen($_SESSION["charDir"], "wb"); 
            fwrite($fOpen, $sourceStr, strlen($sourceStr));
            fclose($fOpen);


            echo "JOB HAS BEEN UPDATED!";

            echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
        }
    }
?>
