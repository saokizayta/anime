<?if (XPT!=1) exit;?>


<?
        if(in_array($_SESSION["ID"],$adminList))
        {
            if($_POST[action]!="getpw")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td colspan="2"><img src="imgs/box/showpw.gif" alt="showpw" width="161" height="9"></td>
              </tr>
              <tr>
                <td width="15%">ID</td>
                <td><input type="text" name="username" value="<?=$_SESSION["ID"]?>" size="20" maxlength="10"></td>
              </tr>
              <tr>
                <td colspan="2"><input type="submit" value="get" class="button"> <input type="reset" value="clear" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="getpw">

            </form>
<?
            }
            else
            {
                $usernameP=($_POST[username])?$_POST[username]:$_SESSION[userid];
                if(in_array($_SESSION["ID"],$adminList))
                {
                    $connection = odbc_connect( $connection_string, $user, $pass );

                    $query = "SELECT * FROM [accountdb].[dbo].[".( strtoupper($usernameP[0]) ) ."GameUser] WHERE [userid]='$usernameP'";
                    $q = odbc_exec($connection, $query);

                    $qt = odbc_do($connection, $query);
                    $i = 0;
                    while(odbc_fetch_row($qt)) $i++;

                    if($i>0)
                        $farr = odbc_fetch_array($q);
                    else
                    echo "USERNAME IS NOT EXISTING!";

                    echo "PASSWORD OF USERNAME <b>$usernameP</b> IS <b>$farr[Passwd]</b>";
                }
                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
            }
        }


            if($_POST[action]!="changepw")
            {
?>

            <form method="post" onSubmit="disabledBttn(this)" action="<?=$_SERVER[PHP_SELF]."?".$_SERVER[QUERY_STRING]?>">
            <table width="100%" border="0" align="center" cellpadding="2" cellspacing="2">
              <tr>
                <td colspan="2"><img src="imgs/box/changepw.gif" alt="statement" width="184" height="9"></td>
              </tr>
<?
                if( in_array($_SESSION["ID"],$adminList) )
                {
?>
              <tr>
                <td width="15%">ID</td>
                <td><input type="text" name="username" value="<?=$_SESSION["ID"]?>" size="20" maxlength="10"></td>
              </tr>
<?
                }
                else
                {
?>
              <tr>
                <td width="15%">ID</td>
                <td><input type="hidden" name="username" value="<?=$_SESSION["ID"]?>"><?=$_SESSION["ID"]?></td>
              </tr>
<?
                }
?>
              <tr>
                <td>OLD PW</td><td><input type="password" name="oldpwd" size="20" maxlength="8"></td>
              </tr>
              <tr>
                <td>NEW PW1</td><td><input type="password" name="pwd1" size="20" maxlength="8"></td>
              </tr>
              <tr>
                <td>NEW PW2</td><td><input type="password" name="pwd2" size="20" maxlength="8"></td>
              </tr>
              <tr>
                <td colspan="2"><input type="submit" value="change" class="button"> <input type="reset" value="clear" class="button"></td>
              </tr>
            </table>
            <input type="hidden" name="action" value="changepw">

            </form>

<?
            }
            else
            {
                    $required=array(
                    "OLD PW"=>$_POST[oldpwd],
                    "NEW PW1"=>$_POST[pwd1],
                    "NEW PW2"=>$_POST[pwd2],
                );

                for($i=0;$i<count($required);$i++)
                {
                    list($key,$value)=each($required);

                    if(!$value)
                        echo "<b>$key</b> is required<br>";
                    else
                        $chkArr[]=true;
                }

                if(count($chkArr)==count($required))
                {

                    if($_POST[pwd1]==$_POST[pwd2])
                    {
                        $connection = odbc_connect( $connection_string, $user, $pass );

                        $usernameP=($_SESSION["ID"]==$_POST[username])?$_SESSION["ID"]:$_POST[username];

                        $query = "SELECT * FROM [accountdb].[dbo].[".( strtoupper($usernameP[0]) ) ."GameUser] WHERE [userid]='$usernameP' AND [Passwd]='$_POST[oldpwd]'";
                        $q = odbc_exec($connection, $query);

                        $qt = odbc_do($connection, $query);
                        $i = 0;
                        while(odbc_fetch_row($qt)) $i++;

                        if($i>0)
                        {

                            if(!$func->is_valid_string($_POST[pwd1]))
                            {

                                $query = "UPDATE [accountdb].[dbo].[".( strtoupper($usernameP[0]) ) ."GameUser] SET [Passwd]='$_POST[pwd1]' WHERE [userid]='$usernameP' AND [Passwd]='$_POST[oldpwd]'";
                                $q = odbc_exec($connection, $query);
                                if($q)
                                {
                                    echo "PASSWORD HAS BEEN CHANGED!<br>";
                                    echo "PLEASE RELOG WITH NEW PASSWORD!";
                                }
                            }
                            else
                            {
                                    echo "PLEASE RE-ENTER USENAME AND PASSWORD, REMOVE ALL SPECIAL CHARACTER!<br>";
                            }

                        }
                        else
                        {
                            echo "PLEASE RE-ENTER OLD PASSWORD!<br>";
                         }
                        }
                    else
                    {
                        echo "NEW PW1 AND NEW PW2 ARE NOT THE SAME CHARACTER<br>";

                    }

                }

                echo "<br><a href=\"$_SERVER[PHP_SELF]?$_SERVER[QUERY_STRING]\">BACK</a>";
            }


?>